module.exports = {
  content: ["./src/**/*.{html,js,ts}","index.html"],
  theme: {
    extend: {},
  },
  plugins: [],
}
